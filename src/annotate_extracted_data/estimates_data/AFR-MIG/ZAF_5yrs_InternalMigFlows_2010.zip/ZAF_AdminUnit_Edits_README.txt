The following edits have been made before extracting the centroids:

polygons representing Prince Edward Islands in the Admin-1 GADM shapefile have been removed.