The following edits have been made before extracting the centroids:

the 4 polygons in the Admin-2 GADM shapefile representing the circles of Abe�bara, Kidal, Tessalit and Tin-Essako have been merged together.