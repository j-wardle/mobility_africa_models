The following edits have been made before extracting the centroids:

1) new polygons representing Blantyre City, Lilongwe City, Mzimba City, and Zomba City have been added to the Admin-1 GADM shapefile;

2) the polygon representing the district of Mwanza in the Admin-1 GADM shapefile has beed subdivided into 2 polygons representing the districts of Neno and Mwanza. 



