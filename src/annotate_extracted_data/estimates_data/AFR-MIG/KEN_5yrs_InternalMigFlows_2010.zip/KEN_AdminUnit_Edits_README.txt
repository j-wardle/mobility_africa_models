The following edits have been made before extracting the centroids:

1) polygons representing the 2 districts of Wajir (in both the Eastern and North-Eastern region) in the Admin-2 GADM shapefile have been merged together;

2) polygons representing the districts of Machakos (in both the Central and Eastern region) in the Admin-2 GADM shapefile have been merged together.