The following edits have been made before extracting the centroids:

1) the polygon representing the department of Pikine in the Admin-2 GADM shapefile has been subdivided into 2 polygons representing the departments of Pikine and Gu�diawaye;

2) the 2 polygons representing the departments of Lingu�re and Matam in the Admin-2 GADM shapefile has been subdivided into 4 polygons representing the departments of Linguere, Ranerou Ferlo, Matam, and Kanel;

3) the polygon representing the department of Dagana in the Admin-2 GADM shapefile has been subdivided into 2 polygons representing the departments of Saint Louis and Dagana.