The following edits have been made before extracting the centroids:

the 2 polygons in the Admin-2 GADM shapefile representing the states of West and South Kordofan have been merged together.